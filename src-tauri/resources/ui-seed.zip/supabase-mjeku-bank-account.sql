-- Add bank_account column to clinic_registry for cross-device sync.
-- Run once on Supabase; idempotent.
ALTER TABLE clinic_registry ADD COLUMN IF NOT EXISTS bank_account text;
